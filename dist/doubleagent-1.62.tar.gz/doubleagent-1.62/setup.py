from setuptools import find_packages
import setuptools
setuptools.setup(
    name="doubleagent",
    version="1.62",
    license='MIT',
    author="complexplayer",
    author_email="didutc@gmail.com",
    description="for me",

    url="",
    packages=setuptools.find_packages(),
    classifiers=[
        # 패키지에 대한 태그
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent"
    ],
)

