import random


def mix(list):
    xo = list[:]
    random.shuffle(xo)
    return xo
