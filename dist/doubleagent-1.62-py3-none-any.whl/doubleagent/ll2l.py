def ll2l(array_array_array):
    mody = []
    for array_array in array_array_array:
        for array in array_array:
            mody.append(array)

    return mody
