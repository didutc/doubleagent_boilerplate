def sublist(target1,target2):
    target = [x for x in target1 if x not in target2]
    return target