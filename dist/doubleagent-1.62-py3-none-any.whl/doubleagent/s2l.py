

def s2l(one):
    array = [one]
    return array
